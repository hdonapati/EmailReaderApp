﻿namespace Email_Reader_Application
{
    partial class EmailReader
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbAddEmailSubject = new System.Windows.Forms.GroupBox();
            this.btnDeleteLookup = new System.Windows.Forms.Button();
            this.tbSubjectLine = new System.Windows.Forms.TextBox();
            this.lblSavedLookup = new System.Windows.Forms.Label();
            this.btnAddLookup = new System.Windows.Forms.Button();
            this.lbSavedLookups = new System.Windows.Forms.ListBox();
            this.tbLookupName = new System.Windows.Forms.TextBox();
            this.lblLookupName = new System.Windows.Forms.Label();
            this.lblSubjectLine = new System.Windows.Forms.Label();
            this.lblOutputFolder = new System.Windows.Forms.Label();
            this.tbOutputFolder = new System.Windows.Forms.TextBox();
            this.lblSubjectToSearch = new System.Windows.Forms.Label();
            this.tbEmailSubject = new System.Windows.Forms.TextBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.tbExcelSheet = new System.Windows.Forms.TextBox();
            this.lblExcelSheet = new System.Windows.Forms.Label();
            this.btnScanEmails = new System.Windows.Forms.Button();
            this.gbAddEmailSubject.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbAddEmailSubject
            // 
            this.gbAddEmailSubject.Controls.Add(this.btnDeleteLookup);
            this.gbAddEmailSubject.Controls.Add(this.tbSubjectLine);
            this.gbAddEmailSubject.Controls.Add(this.lblSavedLookup);
            this.gbAddEmailSubject.Controls.Add(this.btnAddLookup);
            this.gbAddEmailSubject.Controls.Add(this.lbSavedLookups);
            this.gbAddEmailSubject.Controls.Add(this.tbLookupName);
            this.gbAddEmailSubject.Controls.Add(this.lblLookupName);
            this.gbAddEmailSubject.Controls.Add(this.lblSubjectLine);
            this.gbAddEmailSubject.Location = new System.Drawing.Point(12, 12);
            this.gbAddEmailSubject.Name = "gbAddEmailSubject";
            this.gbAddEmailSubject.Size = new System.Drawing.Size(539, 1156);
            this.gbAddEmailSubject.TabIndex = 0;
            this.gbAddEmailSubject.TabStop = false;
            this.gbAddEmailSubject.Text = "Email Subject";
            // 
            // btnDeleteLookup
            // 
            this.btnDeleteLookup.Location = new System.Drawing.Point(59, 1023);
            this.btnDeleteLookup.Name = "btnDeleteLookup";
            this.btnDeleteLookup.Size = new System.Drawing.Size(425, 58);
            this.btnDeleteLookup.TabIndex = 3;
            this.btnDeleteLookup.Text = "Delete Lookup";
            this.btnDeleteLookup.UseVisualStyleBackColor = true;
            this.btnDeleteLookup.Click += new System.EventHandler(this.btnDeleteLookup_Click);
            // 
            // tbSubjectLine
            // 
            this.tbSubjectLine.Location = new System.Drawing.Point(27, 251);
            this.tbSubjectLine.Name = "tbSubjectLine";
            this.tbSubjectLine.Size = new System.Drawing.Size(464, 47);
            this.tbSubjectLine.TabIndex = 0;
            // 
            // lblSavedLookup
            // 
            this.lblSavedLookup.AutoSize = true;
            this.lblSavedLookup.Location = new System.Drawing.Point(27, 453);
            this.lblSavedLookup.Name = "lblSavedLookup";
            this.lblSavedLookup.Size = new System.Drawing.Size(218, 41);
            this.lblSavedLookup.TabIndex = 0;
            this.lblSavedLookup.Text = "Saved Lookups";
            // 
            // btnAddLookup
            // 
            this.btnAddLookup.Location = new System.Drawing.Point(59, 326);
            this.btnAddLookup.Name = "btnAddLookup";
            this.btnAddLookup.Size = new System.Drawing.Size(425, 58);
            this.btnAddLookup.TabIndex = 3;
            this.btnAddLookup.Text = "Save Lookup";
            this.btnAddLookup.UseVisualStyleBackColor = true;
            this.btnAddLookup.Click += new System.EventHandler(this.btnAddLookup_Click);
            // 
            // lbSavedLookups
            // 
            this.lbSavedLookups.FormattingEnabled = true;
            this.lbSavedLookups.ItemHeight = 41;
            this.lbSavedLookups.Location = new System.Drawing.Point(38, 518);
            this.lbSavedLookups.Name = "lbSavedLookups";
            this.lbSavedLookups.Size = new System.Drawing.Size(464, 455);
            this.lbSavedLookups.TabIndex = 2;
            this.lbSavedLookups.SelectedIndexChanged += new System.EventHandler(this.lbSavedLookups_SelectedIndexChanged);
            // 
            // tbLookupName
            // 
            this.tbLookupName.Location = new System.Drawing.Point(27, 111);
            this.tbLookupName.Name = "tbLookupName";
            this.tbLookupName.Size = new System.Drawing.Size(464, 47);
            this.tbLookupName.TabIndex = 0;
            // 
            // lblLookupName
            // 
            this.lblLookupName.AutoSize = true;
            this.lblLookupName.Location = new System.Drawing.Point(27, 54);
            this.lblLookupName.Name = "lblLookupName";
            this.lblLookupName.Size = new System.Drawing.Size(254, 41);
            this.lblLookupName.TabIndex = 1;
            this.lblLookupName.Text = "Excel Sheet Name";
            // 
            // lblSubjectLine
            // 
            this.lblSubjectLine.AutoSize = true;
            this.lblSubjectLine.Location = new System.Drawing.Point(27, 194);
            this.lblSubjectLine.Name = "lblSubjectLine";
            this.lblSubjectLine.Size = new System.Drawing.Size(178, 41);
            this.lblSubjectLine.TabIndex = 0;
            this.lblSubjectLine.Text = "Subject Line";
            // 
            // lblOutputFolder
            // 
            this.lblOutputFolder.AutoSize = true;
            this.lblOutputFolder.Location = new System.Drawing.Point(570, 123);
            this.lblOutputFolder.Name = "lblOutputFolder";
            this.lblOutputFolder.Size = new System.Drawing.Size(205, 41);
            this.lblOutputFolder.TabIndex = 1;
            this.lblOutputFolder.Text = "Output Folder";
            // 
            // tbOutputFolder
            // 
            this.tbOutputFolder.Location = new System.Drawing.Point(783, 123);
            this.tbOutputFolder.Name = "tbOutputFolder";
            this.tbOutputFolder.Size = new System.Drawing.Size(1022, 47);
            this.tbOutputFolder.TabIndex = 2;
            // 
            // lblSubjectToSearch
            // 
            this.lblSubjectToSearch.AutoSize = true;
            this.lblSubjectToSearch.Location = new System.Drawing.Point(570, 223);
            this.lblSubjectToSearch.Name = "lblSubjectToSearch";
            this.lblSubjectToSearch.Size = new System.Drawing.Size(194, 41);
            this.lblSubjectToSearch.TabIndex = 3;
            this.lblSubjectToSearch.Text = "Email Subject";
            // 
            // tbEmailSubject
            // 
            this.tbEmailSubject.Location = new System.Drawing.Point(783, 223);
            this.tbEmailSubject.Name = "tbEmailSubject";
            this.tbEmailSubject.Size = new System.Drawing.Size(1022, 47);
            this.tbEmailSubject.TabIndex = 4;
            // 
            // tbExcelSheet
            // 
            this.tbExcelSheet.Location = new System.Drawing.Point(783, 322);
            this.tbExcelSheet.Name = "tbExcelSheet";
            this.tbExcelSheet.Size = new System.Drawing.Size(1022, 47);
            this.tbExcelSheet.TabIndex = 4;
            // 
            // lblExcelSheet
            // 
            this.lblExcelSheet.AutoSize = true;
            this.lblExcelSheet.Location = new System.Drawing.Point(570, 322);
            this.lblExcelSheet.Name = "lblExcelSheet";
            this.lblExcelSheet.Size = new System.Drawing.Size(167, 41);
            this.lblExcelSheet.TabIndex = 3;
            this.lblExcelSheet.Text = "Excel Sheet";
            // 
            // btnScanEmails
            // 
            this.btnScanEmails.Location = new System.Drawing.Point(940, 465);
            this.btnScanEmails.Name = "btnScanEmails";
            this.btnScanEmails.Size = new System.Drawing.Size(188, 58);
            this.btnScanEmails.TabIndex = 5;
            this.btnScanEmails.Text = "Scan Emails";
            this.btnScanEmails.UseVisualStyleBackColor = true;
            this.btnScanEmails.Click += new System.EventHandler(this.btnScanEmails_Click);
            // 
            // EmailReader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 41F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1921, 1180);
            this.Controls.Add(this.btnScanEmails);
            this.Controls.Add(this.lblExcelSheet);
            this.Controls.Add(this.tbExcelSheet);
            this.Controls.Add(this.tbEmailSubject);
            this.Controls.Add(this.lblSubjectToSearch);
            this.Controls.Add(this.tbOutputFolder);
            this.Controls.Add(this.lblOutputFolder);
            this.Controls.Add(this.gbAddEmailSubject);
            this.Name = "EmailReader";
            this.Text = "Email Reader for Training Updates";
            this.Load += new System.EventHandler(this.EmailReader_Load);
            this.gbAddEmailSubject.ResumeLayout(false);
            this.gbAddEmailSubject.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbAddEmailSubject;
        private System.Windows.Forms.Label lblLookupName;
        private System.Windows.Forms.Label lblSubjectLine;
        private System.Windows.Forms.TextBox tbSubjectLine;
        private System.Windows.Forms.ListBox lbSavedLookups;
        private System.Windows.Forms.TextBox tbLookupName;
        private System.Windows.Forms.Button btnDeleteLookup;
        private System.Windows.Forms.Label lblSavedLookup;
        private System.Windows.Forms.Button btnAddLookup;
        private System.Windows.Forms.Label lblOutputFolder;
        private System.Windows.Forms.TextBox tbOutputFolder;
        private System.Windows.Forms.Label lblSubjectToSearch;
        private System.Windows.Forms.TextBox tbEmailSubject;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.TextBox tbExcelSheet;
        private System.Windows.Forms.Label lblExcelSheet;
        private System.Windows.Forms.Button btnScanEmails;
    }
}

