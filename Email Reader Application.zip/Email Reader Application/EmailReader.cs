﻿using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Resources;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Email_Reader_Application.Models;

namespace Email_Reader_Application
{
    public partial class EmailReader : Form
    {

        Dictionary<string, string> Lookup_Subject = new Dictionary<string, string>();
        Dictionary<string, DateTime> searchTag_Date = new Dictionary<string, DateTime>();

        public EmailReader()
        {
            InitializeComponent();
        }

        private void EmailReader_Load(object sender, EventArgs e)
        {
            CheckAndReadJSON();
        }

        #region LookUp
        private void CheckAndReadJSON()
        {
            if (File.Exists(@"appsettings.json"))
            {
                using (StreamReader r = new StreamReader(@"appsettings.json"))
                {
                    try
                    {
                        string json = r.ReadToEnd();
                        var topDict = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);

                        string savedLookUps;

                        if (topDict.TryGetValue("SavedLookups", out savedLookUps))
                        {
                            Lookup_Subject = JsonConvert.DeserializeObject<Dictionary<string, string>>(savedLookUps);
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Error reading app settings.json file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                dynamic jsonObj = new
                {
                    SavedLookups = JsonConvert.SerializeObject(Lookup_Subject, Formatting.Indented)
                };
                string oucrsut = JsonConvert.SerializeObject(jsonObj, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(@"appsettings.json", oucrsut);
            }

            if (Lookup_Subject.Keys.Count > 0)
                lbSavedLookups.DataSource = Lookup_Subject.Keys.ToList();
            else
                lbSavedLookups.DataSource = null;
        }

        private void btnAddLookup_Click(object sender, EventArgs e)
        {
            if (tbSubjectLine.Text.Length > 0 && tbLookupName.Text.Length > 0)
            {
                if (!Lookup_Subject.ContainsKey(tbLookupName.Text))
                {
                    Lookup_Subject.Add(tbLookupName.Text, tbSubjectLine.Text);
                    string json = File.ReadAllText(@"appsettings.json");
                    dynamic jsonObj = JsonConvert.DeserializeObject(json);
                    jsonObj["SavedLookups"] = JsonConvert.SerializeObject(Lookup_Subject, Formatting.Indented); ;
                    string oucrsut = Newtonsoft.Json.JsonConvert.SerializeObject(jsonObj, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(@"appsettings.json", oucrsut);
                    CheckAndReadJSON();
                }
                else
                    MessageBox.Show("The Lokkup name you are trying to add exists. Please change the Lookup name or delete the existing one.", "Change Lookup name", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Please enter Lookup Name and Subject Line", "Feilds Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeleteLookup_Click(object sender, EventArgs e)
        {
            string deleteKey = (string)lbSavedLookups.SelectedItem;
            Lookup_Subject.Remove(deleteKey);
            string json = File.ReadAllText(@"appsettings.json");
            dynamic jsonObj = JsonConvert.DeserializeObject(json);
            jsonObj["SavedLookups"] = JsonConvert.SerializeObject(Lookup_Subject, Formatting.Indented); ;
            string oucrsut = Newtonsoft.Json.JsonConvert.SerializeObject(jsonObj, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(@"appsettings.json", oucrsut);
            CheckAndReadJSON();
        }

        private void lbSavedLookups_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedKey = (string)lbSavedLookups.SelectedItem;
            tbEmailSubject.Text = Lookup_Subject[selectedKey];
            tbExcelSheet.Text = selectedKey;
        }

        #endregion

        

        #region Search Outlook

        private void ReadEmails(string subjectLine, string advancedSearchTag, DateTime fromDate)
        {
            Outlook.Application outlookApp = null;
            Outlook.NameSpace outlookNamespace = null;
            Outlook.MAPIFolder inboxFolder = null;
            Outlook.Items mailItems = null;

            try
            {
                outlookApp = new Microsoft.Office.Interop.Outlook.Application();
                outlookNamespace = outlookApp.GetNamespace("MAPI");
                inboxFolder = outlookNamespace.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderInbox);
                string scope = "\'" + inboxFolder.FolderPath + "\'";
                string filter = "urn:schemas:mailheader:subject LIKE \'%" + subjectLine + "%\'"; 
                // AND httpmail:datereceived >= '" + fromDate.ToString("d") + "'" ;
                //string filter = "@SQL=" + "(\"" + "urn:schemas:httpmail:subject like '%" + subjectLine + "%'\") AND (\"" + "urn:schemas:httpmail:datereceived" + " >='" + fromDate.ToString("d") + "'\")";
                Outlook.Search advancedSearch = outlookApp.AdvancedSearch(scope, filter, true, advancedSearchTag);


                if (searchTag_Date.ContainsKey(advancedSearchTag))
                    searchTag_Date[advancedSearchTag] = fromDate;
                else
                    searchTag_Date.Add(advancedSearchTag, fromDate);

                outlookApp.AdvancedSearchComplete += Application_AdvancedSearchComplete;
                

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("ReadEmails Method \n" + ex.Message, "An exception is occured");
            }
            finally
            {
                ReleaseComObject(mailItems);
                ReleaseComObject(inboxFolder);
                ReleaseComObject(outlookNamespace);
                ReleaseComObject(outlookApp);
            }
        }

        private void Application_AdvancedSearchComplete(Outlook.Search SearchObject)
        {
            Outlook.Results advancedSearch = null;
            Outlook.MailItem resultItem = null;

            Dictionary<string, List<Course>> resultSet = new Dictionary<string, List<Course>>();

            try
            {
                if (searchTag_Date.ContainsKey(SearchObject.Tag))
                {
                    DateTime fromDate = searchTag_Date[SearchObject.Tag];
                    advancedSearch = SearchObject.Results;                   

                    if (advancedSearch.Count > 0)
                    {
                        string searchSaveFolder = tbOutputFolder.Text + "\\" + SearchObject.Tag;
                        if (!Directory.Exists(searchSaveFolder))
                            Directory.CreateDirectory(searchSaveFolder);

                        int processedCount = 0;
                        for (int i = 1; i <= advancedSearch.Count; i++)
                        {
                            resultItem = advancedSearch[i] as Microsoft.Office.Interop.Outlook.MailItem;
                            if (resultItem.ReceivedTime >= fromDate)
                            {
                                string senderName = resultItem.SenderName;
                                DateTime receivedDate = resultItem.ReceivedTime;

                                if (resultItem.Attachments.Count > 0)
                                {
                                    string personSaveFolder = searchSaveFolder + "\\" + senderName;
                                    if (!Directory.Exists(personSaveFolder))
                                        Directory.CreateDirectory(personSaveFolder);

                                    foreach (Outlook.Attachment attachment in resultItem.Attachments)
                                    {
                                        string saveAs = personSaveFolder + "\\" + resultItem.ReceivedTime.ToString("yyyy-MM-dd") + "_" + attachment.FileName;
                                        attachment.SaveAsFile(saveAs);

                                        if (attachment.FileName.Contains("xlsx") || attachment.FileName.Contains("xls"))
                                        {
                                            List<Course> courseList = ReadExcelSheet(saveAs, SearchObject.Tag);
                                            resultSet.Add(senderName, courseList);
                                        }
                                           
                                    }
                                }


                                if (resultItem != null)
                                {
                                    Marshal.ReleaseComObject(resultItem);
                                }

                                processedCount += 1;
                            }
                        }


                        if (processedCount > 0)
                        {
                            CreateConsildatedStatusFile(searchSaveFolder, resultSet);
                            MessageBox.Show("AdvancedSearchComplete Method \n" + String.Format("Processed {0} email(s)", processedCount), "Success!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                            MessageBox.Show("AdvancedSearchComplete Method \n" + "No Items found for the Criteria", "No emails found", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    }
                    else
                    {
                        MessageBox.Show("AdvancedSearchComplete Method \n" + "No Items found for the Criteria"  , "No emails found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("AdvancedSearchComplete Method \n" + ex.Message, "An exception is occured");
            }
            finally
            {
                if (resultItem != null) Marshal.ReleaseComObject(resultItem);
                if (advancedSearch != null)
                    Marshal.ReleaseComObject(advancedSearch);
            }
        }

        private void CreateConsildatedStatusFile(string searchSaveFolder, Dictionary<string, List<Course>> resultSet)
        {
            Dictionary<string, Dictionary<string, SubContent>> consolidatedResult = new Dictionary<string, Dictionary<string, SubContent>>();

            Excel.Application oXL = new Excel.Application();
            Excel._Workbook oWB = (Excel._Workbook)(oXL.Workbooks.Add());            
            Excel._Worksheet oSheet = (Excel._Worksheet)oWB.ActiveSheet; oSheet.Name = "Consolidated Status";
            object[] closing = new object[] { oXL, oWB, oSheet};

            object misvalue = System.Reflection.Missing.Value;
            try
            {
                oXL.Visible = false; oXL.DisplayAlerts = false;

                foreach(var kvp in resultSet)
                {
                    int lastCourse = 0; int lastSubCourse = 0;
                    oSheet = oWB.Worksheets.Add();
                    oSheet.Name = kvp.Key;

                    oSheet.Cells[1, 1] = "Course"; oSheet.Cells[1, 2] = "SubContent"; oSheet.Cells[1, 3] = "Status";
                    int row = 2;
                    foreach(var crs in kvp.Value)
                    {
                        lastSubCourse = 0;
                        oSheet.Cells[row, 1] = crs.CourseTitle;
                        foreach(var sc in crs.SubContentList)
                        {
                            oSheet.Cells[row, 2] = sc.SubContentTitle;
                            oSheet.Cells[row, 3] = sc.Status;
                            row += 1;

                            lastSubCourse += sc.Status.Length > 0 ? 1 : 0;
                        }
                        lastCourse += 1;
                    }

                    Excel.Range oRngInner = oSheet.get_Range("A1", "C" + row.ToString());
                    oRngInner.EntireColumn.AutoFit();

                    Dictionary<string, SubContent> kCRS = new Dictionary<string, SubContent>()
                    {
                        {kvp.Value[lastCourse - 1].CourseTitle, kvp.Value[lastCourse - 1].SubContentList[lastSubCourse - 1] }
                    };

                    consolidatedResult.Add(kvp.Key, kCRS);
                }

                oSheet = (Excel.Worksheet)oWB.Worksheets["Consolidated Status"];

                oSheet.Cells[1, 1] = "Trainee"; oSheet.Cells[1, 2] = "Course"; oSheet.Cells[1, 3] = "SubContent"; oSheet.Cells[1, 4] = "Status";
                int cRow = 2;
                foreach(var kvp in consolidatedResult)
                {
                    oSheet.Cells[cRow, 1] = kvp.Key;
                    oSheet.Cells[cRow, 2] = kvp.Value.Keys.FirstOrDefault();
                    oSheet.Cells[cRow, 3] = kvp.Value.Values.FirstOrDefault().SubContentTitle;
                    oSheet.Cells[cRow, 4] = kvp.Value.Values.FirstOrDefault().Status;
                    cRow += 1;
                }
                Excel.Range oRng = oSheet.get_Range("A1", "D" + cRow.ToString());
                oRng.EntireColumn.AutoFit();
                //oXL.Visible = true;
                oWB.SaveAs2(searchSaveFolder + "\\Consolidated Status " + DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss") + ".xlsx", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing,
                               false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                               Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                File.OpenRead(searchSaveFolder + "\\Consolidated Status " + DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss") + ".xlsx");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Write Excel Method \n" + ex.Message, "An exception is occured");
            }
            finally
            {
                oWB.Close(false, Type.Missing, Type.Missing);
                oXL.Quit();
                foreach (var item in closing)
                {
                    ReleaseComObject(item);
                }
            }


                //foreach()
            }

        #endregion

        #region Read Excel

        private List<Course> ReadExcelSheet(string excelFilePath, string sheetName)
        {
        string[] headerTextArray = new string[] { "Title", "Subcontent", "Start Date", "End Date", "Current Status", "Completion Date" };
        string defaultHeaderLookupColumn = headerTextArray[1];
        Dictionary<string, int> headerColumnMapping = new Dictionary<string, int>();
        List<Course> crsList = new List<Course>();
        try
        {
            #region Excel Open
            Excel.Application excelApp = new Excel.Application();
            excelApp.DisplayAlerts = false;
            Excel.Workbook workbook = excelApp.Workbooks.Open(excelFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing); //This opens the file
            Excel.Worksheet sheet = (Excel.Worksheet)workbook.Sheets.get_Item(sheetName);
            Excel.Range cells = sheet.Cells;
            int lastRow = cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing).Row;
            int lastColumn = cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing).Column;
            object[] closing = new object[] { excelApp, workbook, sheet, cells };
            #endregion

            Excel.Range match = cells.Find(defaultHeaderLookupColumn, LookAt: Excel.XlLookAt.xlPart) as Excel.Range;
            var headerRowIndex = -1;
            if (match != null)
            {
                headerRowIndex = match.Row;
                headerColumnMapping.Add(defaultHeaderLookupColumn, match.Column);
                foreach (string colName in headerTextArray)
                {
                    if (!headerColumnMapping.ContainsKey(colName))
                    {
                        match = cells.Find(colName, LookAt: Excel.XlLookAt.xlPart) as Excel.Range;
                        if (match != null)
                            headerColumnMapping.Add(colName, match.Column);
                    }
                }
            }

            string currentTraining = string.Empty;
            if (headerRowIndex > 0 && headerColumnMapping.Count == headerTextArray.Count())
            {
                Course crs = new Course();
                for (int i = headerRowIndex + 1; i < lastRow + 1; i++)
                {
                    string course = GetCellValue(cells, i, headerColumnMapping["Title"]);
                    string subcontent = GetCellValue(cells, i, headerColumnMapping["Subcontent"]);

                    if (String.IsNullOrWhiteSpace(subcontent) && String.IsNullOrWhiteSpace(course))
                    {
                        var subContentStatuses = crs.SubContentList.Select(o => o.Status).Distinct().ToList();
                        crs.CourseStatus = (subContentStatuses.Count > 0 && subContentStatuses.Count == 1 && subContentStatuses[0] == "Completed") ? "Completed" : "Not Completed";
                        crsList.Add(crs);

                        i += 1;
                        crs = GetCourse(cells, i, headerColumnMapping);
                        currentTraining = crs.CourseTitle;

                        if (crs.StartDate > DateTime.Now)
                        {
                            #region Excel Close
                            workbook.Close(false, Type.Missing, Type.Missing);
                            excelApp.Quit();                                
                            foreach (var item in closing)
                            {
                                ReleaseComObject(item);
                            }
                            #endregion
                            return crsList;
                        }
                           

                        subcontent = GetCellValue(cells, i, headerColumnMapping["Subcontent"]);
                        if (String.IsNullOrWhiteSpace(currentTraining))
                        {
                            i += 2;
                            subcontent = GetCellValue(cells, i, headerColumnMapping["Subcontent"]);
                        }
                    }

                    if (String.IsNullOrWhiteSpace(currentTraining))
                    {
                        crs = GetCourse(cells, i, headerColumnMapping);
                        currentTraining = crs.CourseTitle;
                        i += 1;
                    }

                    if (!String.IsNullOrWhiteSpace(subcontent))
                    {
                        SubContent sc = new SubContent();
                        sc.SubContentTitle = subcontent;
                        sc.Status = GetCellValue(cells, i, headerColumnMapping["Current Status"]);
                        var dtString = GetCellValue(cells, i, headerColumnMapping["Completion Date"]);
                        sc.LastUpdatedDate = dtString.Length > 0 ? (dtString.Contains('/') ? Convert.ToDateTime(dtString) : DateTime.FromOADate(Convert.ToDouble(dtString))) : DateTime.MinValue;
                        crs.SubContentList.Add(sc);
                    }
                }
            }

            #region Excel Close
            workbook.Close(false, Type.Missing, Type.Missing);
            excelApp.Quit();
            foreach(var item in closing)
            {
                ReleaseComObject(item);
            }
            #endregion
        }
        catch (System.Exception ex)
        {
            System.Windows.Forms.MessageBox.Show(ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
        }

        return crsList;
    }

        private string GetCellValue(Excel.Range Range, int rowIndex, int colIndex)
        {
            string result = "";

            if (((Excel.Range)Range[rowIndex, colIndex]).Value2 != null)
                result = ((Excel.Range)Range[rowIndex, colIndex]).Value2.ToString();

            return result;
        }

        private Course GetCourse(Excel.Range Range, int rowIndex, Dictionary<string, int> colMapping)
        {
            Course returnData = new Course();

            returnData.CourseTitle = GetCellValue(Range, rowIndex, colMapping["Title"]);
            string courseStartDate = GetCellValue(Range, rowIndex, colMapping["Start Date"]);
            returnData.StartDate = courseStartDate.Length > 0 && courseStartDate.Contains('/') ? Convert.ToDateTime(courseStartDate) : DateTime.FromOADate(Convert.ToDouble(courseStartDate));
            string courseEndDate = GetCellValue(Range, rowIndex, colMapping["End Date"]);
            returnData.EndDate = courseEndDate.Length > 0 && courseEndDate.Contains('/') ? Convert.ToDateTime(courseEndDate) : DateTime.FromOADate(Convert.ToDouble(courseEndDate));

            return returnData;
        }

        private SubContent GetSubContent(Excel.Range Range, string subcontent, int rowIndex, Dictionary<string, int> colMapping)
        {
            SubContent returnData = new SubContent();
            returnData.SubContentTitle = subcontent;
            returnData.Status = GetCellValue(Range, rowIndex, colMapping["Current Status"]);
            var dtString = GetCellValue(Range, rowIndex, colMapping["Completion Date"]);
            returnData.LastUpdatedDate = dtString.Length > 0 ? (dtString.Contains('/') ? Convert.ToDateTime(dtString) : DateTime.FromOADate(Convert.ToDouble(dtString))) : DateTime.MinValue;

            return returnData;
        }

        #endregion

        private static void ReleaseComObject(object obj)
        {
            if (obj != null)
            {
                Marshal.ReleaseComObject(obj);
                obj = null;
            }
        }

        private void btnScanEmails_Click(object sender, EventArgs e)
        {
            if(tbOutputFolder.TextLength > 0 && tbExcelSheet.TextLength > 0 && tbEmailSubject.TextLength > 0)
            {
                if (Directory.Exists(tbOutputFolder.Text))
                {
                    ReadEmails(tbEmailSubject.Text, tbExcelSheet.Text, DateTime.Now);
                }
                else
                    MessageBox.Show("The entered output directory does not exist", "Output Directory", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            else
            {
                MessageBox.Show("Please enter all the fields above", "Feilds Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
    }
}
