﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Email_Reader_Application.Models
{
    class Course
    {
        public string CourseTitle { get; set; }
        public string CourseStatus { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public List<SubContent> SubContentList = new List<SubContent>(); //{ get; set; }
    }
}
