﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Email_Reader_Application.Models
{
    class SubContent
    {
        public string SubContentTitle { get; set; }
        public string Status { get; set; }
        public DateTime LastUpdatedDate { get; set; }

    }
}
